object fourth{
    def main(args: Array[String]): Unit={
        var profit1 = income(120, 15) - ownerCost(120)
        var profit2 = income(140, 10) - ownerCost(140)
        var profit3 = income(100, 20) - ownerCost(100)
        if((profit1 > profit2) && (profit1 > profit3)){
            println("Best Ticket Price is: Rs."+15)
            print("Profit gain: Rs."+profit1)
        }
        else if((profit2 > profit1) && (profit2 > profit3)){
            println("Best Ticket Price is: Rs."+10)
            print("Profit gain: Rs."+profit2)
        }
        else{
            println("Best Ticket Price is: Rs."+20)
            print("Profit gain: Rs."+profit3)
        }
    }

    def ownerCost(x:Int): Int = 3 * x + 500
    
    def income(x:Int, y:Int): Int = x*y

}